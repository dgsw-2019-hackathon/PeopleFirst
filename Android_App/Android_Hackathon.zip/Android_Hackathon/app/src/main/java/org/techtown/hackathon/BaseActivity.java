package org.techtown.hackathon;

import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import android.os.Bundle;
import android.view.WindowManager;
import androidx.annotation.LayoutRes;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public abstract class BaseActivity<VB extends ViewDataBinding> extends AppCompatActivity {

    protected VB binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLayoutNoLimits(true);
        binding = DataBindingUtil.setContentView(this, layoutId());
    }

    @LayoutRes
    protected abstract int layoutId();


    /**
     * LAYOUT_NO_LIMITS 설정, 기본적으로 사용 됨
     *
     * @param enable LAYOUT_NO_LIMITS 의 사용 여부
     */
    protected final void setLayoutNoLimits(boolean enable) {
        if (enable)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        else
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
    }




    @Override
    protected void onDestroy() {
        super.onDestroy();
        //binding 을 null 로 설정하여 누수되지 않고 GC 되도록 함
        binding = null;
    }
}