package org.techtown.hackathon;

import android.os.Bundle;

public class MainActivity extends BaseActivity<> {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected int layoutId() {
        return R.layout.activity_login;
    }
}
